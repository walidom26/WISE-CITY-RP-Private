#!/usr/bin/env bash
# تصريف الجيم مود. عدّل مسار pawncc ومجلد include الخاص بمكتباتك.
PAWNCC="${PAWNCC:-pawncc}"
INC="${INC:-./pawno/include}"
cd "$(dirname "$0")/../gamemodes" || exit 1
"$PAWNCC" wise_city.pwn -i"$INC" -d3 -; echo "انتهى التصريف"
