@echo off
rem عدّل مسار pawncc ومجلد include ثم شغّل الملف
set PAWNCC=pawncc.exe
set INC=..\pawno\include
cd /d "%~dp0..\gamemodes"
%PAWNCC% wise_city.pwn -i%INC% -d3
pause
